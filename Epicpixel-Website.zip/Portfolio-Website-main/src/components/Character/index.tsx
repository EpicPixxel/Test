import Scene from "./Scene";

const CharacterModel = () => {
  return <Scene />;
};

export default CharacterModel;
